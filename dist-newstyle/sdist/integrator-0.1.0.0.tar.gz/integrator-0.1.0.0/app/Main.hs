module Main where

import Text.Parsec
import Text.Parsec.String
import Text.ParserCombinators.Parsec.Number

data Express = App Express Express | Lam Express | Int deriving (Eq, Show)
main :: IO ()
main = do
  print $ parse (try (int >> char '+' >> int) <|> (int >> space >> int)) "" "1+1"


-- myParser "((ll2)(l1))"

--myParser = parse (try ((Lam . myParser) <$> char '(' >> char 'l' >> (many1 anyChar) <* char ')') <|> int) ""


--(Add <$> int <*> (char '+' >> int)) <|> (Mul <$> int <*> (space >> int)))
